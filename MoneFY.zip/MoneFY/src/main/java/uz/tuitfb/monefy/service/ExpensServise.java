package uz.tuitfb.monefy.service;

import org.springframework.stereotype.Service;
import uz.tuitfb.monefy.domain.Expens;
import uz.tuitfb.monefy.repository.ExpensRepository;

@Service
public class ExpensServise {
    private final ExpensRepository expensRepository;

    public ExpensServise(ExpensRepository expensRepository) {
        this.expensRepository = expensRepository;
    }

    public Expens save(Expens expens) {
        return expensRepository.save(expens);
    }

    public boolean checkExpenseName(String name) {
        return expensRepository.existsByName(name);
    }

}
