package uz.tuitfb.monefy.webrest;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.tuitfb.monefy.domain.ExpensTable;
import uz.tuitfb.monefy.service.ExpensTableService;

@RestController
@RequestMapping("/api")
public class ExpenseTableResource {
    private final ExpensTableService expensTableService;


    public ExpenseTableResource(ExpensTableService expensTableService) {
        this.expensTableService = expensTableService;
    }

    @PostMapping("/addExpenseTable")
    public ResponseEntity addExpenseTable(@RequestBody ExpensTable expensTable) {
        return ResponseEntity.ok(expensTableService.save(expensTable));
    }

}
