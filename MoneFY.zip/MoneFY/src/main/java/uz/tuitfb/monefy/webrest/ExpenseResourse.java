package uz.tuitfb.monefy.webrest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.tuitfb.monefy.domain.Expens;
import uz.tuitfb.monefy.service.ExpensServise;

@RestController
@RequestMapping("/api")
public class ExpenseResourse {

    private final ExpensServise expensServise;

    public ExpenseResourse(ExpensServise expensServise) {
        this.expensServise = expensServise;
    }

    @PostMapping("/addExpense")
    public ResponseEntity addExpenseName(@RequestBody Expens expens) {
        if (expensServise.checkExpenseName(expens.getName())) {
            return new ResponseEntity("Bu nomdagi Xarajadlar jadvali mavjud", HttpStatus.BAD_REQUEST);
        } else {
            return ResponseEntity.ok(expensServise.save(expens));
        }
    }
}
