package uz.tuitfb.monefy.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
public class ExpensTable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long user_id;

    private String expensType;

    private float summa;

    private Date date;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public String getExpensType() {
        return expensType;
    }

    public void setExpensType(String expensType) {
        this.expensType = expensType;
    }

    public float getSumma() {
        return summa;
    }

    public void setSumma(float summa) {
        this.summa = summa;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
