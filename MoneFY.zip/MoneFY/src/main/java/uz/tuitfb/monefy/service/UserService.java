package uz.tuitfb.monefy.service;

import org.springframework.stereotype.Service;
import uz.tuitfb.monefy.domain.User;
import uz.tuitfb.monefy.repository.UserRepository;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User save(User user) {
        return userRepository.save(user);
    }
}
