package uz.tuitfb.monefy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.tuitfb.monefy.domain.ExpensTable;

@Repository
public interface ExpensTableRepository extends JpaRepository<ExpensTable,Long> {

}
