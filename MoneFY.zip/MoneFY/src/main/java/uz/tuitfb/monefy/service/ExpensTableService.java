package uz.tuitfb.monefy.service;

import org.springframework.stereotype.Service;
import uz.tuitfb.monefy.domain.ExpensTable;
import uz.tuitfb.monefy.repository.ExpensTableRepository;

@Service
public class ExpensTableService {

    private final ExpensTableRepository expensTableRepository;

    public ExpensTableService(ExpensTableRepository expensTableRepository) {
        this.expensTableRepository = expensTableRepository;
    }

    public ExpensTable save(ExpensTable expensTable) {
        return expensTableRepository.save(expensTable);
    }

}
