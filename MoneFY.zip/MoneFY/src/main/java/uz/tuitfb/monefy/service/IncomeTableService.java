package uz.tuitfb.monefy.service;

import org.springframework.stereotype.Service;
import uz.tuitfb.monefy.domain.IncomeTable;
import uz.tuitfb.monefy.repository.IncomeTableRepository;

@Service
public class IncomeTableService {

    private  final IncomeTableRepository incomeTableRepository;

    public IncomeTableService(IncomeTableRepository incomeTableRepository) {
        this.incomeTableRepository = incomeTableRepository;
    }
    public IncomeTable save(IncomeTable incomeTable){
        return incomeTableRepository.save(incomeTable);
    }
}
