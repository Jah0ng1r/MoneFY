package uz.tuitfb.monefy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoneFyApplication {

    public static void main(String[] args) {
        SpringApplication.run(MoneFyApplication.class, args);
    }

}
