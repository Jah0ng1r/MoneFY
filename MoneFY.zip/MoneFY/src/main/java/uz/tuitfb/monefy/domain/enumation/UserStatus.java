package uz.tuitfb.monefy.domain.enumation;

public enum UserStatus {
DRAFT,ACTIVE
}
