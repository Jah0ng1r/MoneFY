package uz.tuitfb.monefy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.tuitfb.monefy.domain.Expens;

@Repository
public interface ExpensRepository extends JpaRepository<Expens,String> {

    boolean  existsByName(String name);

}
