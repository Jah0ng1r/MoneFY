package uz.tuitfb.monefy.webrest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.tuitfb.monefy.domain.Income;
import uz.tuitfb.monefy.service.IncomeServise;

@RestController
@RequestMapping("/api")
public class IncomeResource {
    private final IncomeServise incomeServise;

    public IncomeResource(IncomeServise incomeServise) {
        this.incomeServise = incomeServise;
    }

    @PostMapping("/addIncome")
    public ResponseEntity addIncome(@RequestBody Income income) {
        if (incomeServise.checkIncomeName(income.getName())) {
            return new ResponseEntity("Bu nomdagi foyda jadvalda mavjud", HttpStatus.BAD_REQUEST);
        } else {
            return ResponseEntity.ok(incomeServise.save(income));
        }

    }
}
