package uz.tuitfb.monefy.service;

import org.springframework.stereotype.Service;
import uz.tuitfb.monefy.domain.Income;
import uz.tuitfb.monefy.repository.IncomeRepository;

@Service
public class IncomeServise {

    private final IncomeRepository incomeRepository;

    public IncomeServise(IncomeRepository incomeRepository) {
        this.incomeRepository = incomeRepository;
    }

    public Income save(Income income) {
        return incomeRepository.save(income);
    }
    public boolean checkIncomeName(String name){
        return incomeRepository.existsByName(name);
    }


}
