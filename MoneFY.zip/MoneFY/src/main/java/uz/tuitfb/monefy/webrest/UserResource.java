package uz.tuitfb.monefy.webrest;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.tuitfb.monefy.domain.User;
import uz.tuitfb.monefy.service.UserService;

@RestController
@RequestMapping("/api")
public class UserResource {

    private final UserService userService;

    public UserResource(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity createUser(@RequestBody User user){
        if(checkPasswordlengh(user.getPassword())){
            return ResponseEntity.ok(userService.save(user));
        }else{
           return new ResponseEntity("Parol uzunligi 4tadan kam", HttpStatus.BAD_REQUEST);
        }
    }
    private Boolean checkPasswordlengh(String password) {

        return password.length() >= 4;
    }
}
