1) odam registratsiya qilib kiradi
2) o'zi uchun categoryalar yaratagi(salomatlik,  ovqatlanish)