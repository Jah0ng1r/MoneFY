package uz.tuitfb.monefy.webrest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.tuitfb.monefy.domain.IncomeTable;
import uz.tuitfb.monefy.service.IncomeTableService;

import java.util.Date;

@RestController
@RequestMapping("/api")
public class IncomeTableResource {
    private final IncomeTableService incomeTableService;
    public IncomeTableResource(IncomeTableService incomeTableService) {
        this.incomeTableService = incomeTableService;
    }

    @PostMapping("/addIncomTable")
    public ResponseEntity addIncomeTable(@RequestBody IncomeTable incomeTable) {

        return ResponseEntity.ok(incomeTableService.save(incomeTable));

    }


}
