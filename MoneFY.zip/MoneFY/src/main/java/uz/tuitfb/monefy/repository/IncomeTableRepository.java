package uz.tuitfb.monefy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uz.tuitfb.monefy.domain.IncomeTable;

@Repository
public interface IncomeTableRepository extends JpaRepository<IncomeTable,Long> {

}
